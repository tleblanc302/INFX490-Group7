<?php
include '../resources/config.php';

// Check if the form is submitted for creating a gift card
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_gift_card'])) {
    // Retrieve form data
    $cardNumber = $_POST['cardNumber'];
    $balance = $_POST['balance'];
    $status = $_POST['status'];

    // Insert gift card details into the database
    $query = "INSERT INTO gift_cards (CardNumber, Balance, Status) VALUES ('$cardNumber', '$balance', '$status')";

    // Execute the query
    if (mysqli_query($conn, $query)) {
        // Gift card created successfully, you can redirect to a success page or show a success message
        $create_success_message = "Gift card created successfully!";
    } else {
        // Handle the error, redirect to an error page or show a message
        $create_error_message = "Error creating gift card: " . mysqli_error($conn);
    }
}

// Check if the form is submitted for editing a gift card
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_gift_card'])) {
    // Retrieve form data
    $cardID = $_POST['cardID'];
    $cardNumber = $_POST['edit_cardNumber'];
    $balance = $_POST['edit_balance'];
    $status = $_POST['edit_status'];

    // Update gift card details in the database
    $query = "UPDATE gift_cards
              SET CardNumber='$cardNumber',
                  Balance='$balance',
                  Status='$status'
              WHERE CardID='$cardID'";

    // Execute the query
    if (mysqli_query($conn, $query)) {
        // Gift card updated successfully, you can redirect to a success page or show a success message
        $edit_success_message = "Gift card updated successfully!";
    } else {
        // Handle the error, redirect to an error page or show a message
        $edit_error_message = "Error updating gift card: " . mysqli_error($conn);
    }
}

// Initialize variables for search functionality
$search_result = "";
$search_error_message = "";

// Check if the form is submitted for searching a gift card by number
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search_gift_card'])) {
    // Retrieve form data
    $search_cardNumber = $_POST['search_cardNumber'];

    // Query the database for the gift card with the specified number
    $search_query = "SELECT CardNumber, Balance, Status FROM gift_cards WHERE CardNumber='$search_cardNumber'";
    $search_result = mysqli_query($conn, $search_query);

    // Check if the search query returned any results
    if (mysqli_num_rows($search_result) > 0) {
        // Gift card found, display the result
        $search_row = mysqli_fetch_assoc($search_result);
    } else {
        // Gift card not found, display an error message
        $search_error_message = "No gift card found with the specified number.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <style>
        /* Adjustments for panel layout */
        .panel-container {
            display: flex;
            justify-content: space-around;
            align-items: flex-start;
        }

        .panel {
            flex: 1;
            margin: 10px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
    </style>
    <title>Gift Card Management</title>
</head>
<body>
<!-- Menu -->
<div class="menu-container">
    <a href="../sales/sales.html" class="menu-item">Sales</a>
    <a href="../view_inventory_sales.html" class="menu-item">View Inventory</a>
    <a href="../view_customers.html" class="menu-item">View Customers</a>
    <a href="../add_customer/add_customer.html" class="menu-item">Add Customer</a>
    <a href="../process_return/process_return.php" class="menu-item">Process Return</a>
    <a href="gift_cards.php" class="menu-item">Gift Card</a>
    <button onclick="window.location.href = '../logout.php'">Logout</button>
</div>

<h1>Gift Card Management</h1>

<div class="panel-container">
    <!-- Create Gift Card Panel -->
    <div class="panel">
        <h2>Create Gift Card</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <label for="cardNumber">Card Number:</label>
            <input type="text" id="cardNumber" name="cardNumber" required>

            <label for="balance">Balance:</label>
            <input type="text" id="balance" name="balance" required>

            <label for="status">Status:</label>
            <select id="status" name="status">
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>

            <button type="submit" name="create_gift_card">Create Gift Card</button>
        </form>
        <?php if(isset($create_success_message)) { ?>
            <p><?php echo $create_success_message; ?></p>
        <?php } ?>
        <?php if(isset($create_error_message)) { ?>
            <p><?php echo $create_error_message; ?></p>
        <?php } ?>
    </div>

    <!-- Edit Gift Card Panel -->
    <div class="panel">
        <h2>Edit Gift Card</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <label for="edit_cardID">Card ID:</label>
            <input type="text" id="edit_cardID" name="cardID" required>

            <label for="edit_cardNumber">Card Number:</label>
            <input type="text" id="edit_cardNumber" name="edit_cardNumber" required>

            <label for="edit_balance">Balance:</label>
            <input type="text" id="edit_balance" name="edit_balance" required>

            <label for="edit_status">Status:</label>
            <select id="edit_status" name="edit_status">
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>

            <button type="submit" name="edit_gift_card">Edit Gift Card</button>
        </form>
        <?php if(isset($edit_success_message)) { ?>
            <p><?php echo $edit_success_message; ?></p>
        <?php } ?>
        <?php if(isset($edit_error_message)) { ?>
            <p><?php echo $edit_error_message; ?></p>
        <?php } ?>
    </div>

    <!-- View Gift Card Balance Panel -->
    <div class="panel">
        <h2>View Gift Card Balance</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <label for="search_cardNumber">Search by Card Number:</label>
            <input type="text" id="search_cardNumber" name="search_cardNumber" required>
            <button type="submit" name="search_gift_card">Search</button>
        </form>
        <?php if(isset($search_row)) { ?>
            <table>
                <thead>
                    <tr>
                        <th>Card Number</th>
                        <th>Balance</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo $search_row['CardNumber']; ?></td>
                        <td><?php echo $search_row['Balance']; ?></td>
                        <td><?php echo $search_row['Status']; ?></td>
                    </tr>
                </tbody>
            </table>
        <?php } ?>
        <?php if(isset($search_error_message)) { ?>
            <p><?php echo $search_error_message; ?></p>
        <?php } ?>
    </div>
</div>

</body>
</html>
