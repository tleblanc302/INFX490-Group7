<?php
include '../resources/config.php';

// Assuming you have a database connection established

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $cardID = $_POST['cardID'];
    $cardNumber = $_POST['cardNumber'];
    $balance = $_POST['balance'];
    $status = $_POST['status'];
    // Retrieve other form fields similarly

    // Update gift card details in the database
    $query = "UPDATE gift_cards
              SET CardNumber='$cardNumber',
                  Balance='$balance',
                  Status='$status'
              WHERE CardID='$cardID'";

    // Execute the query
    if (mysqli_query($conn, $query)) {
        // Gift card updated successfully, you can redirect to a success page
        header("Location: edit_gift_card_success.php");
        exit();
    } else {
        // Handle the error, redirect to an error page or show a message
        echo "Error updating gift card: " . mysqli_error($conn);
    }
} else {
    // Redirect to an error page or handle appropriately
    header("Location: error_page.php");
    exit();
}
?>
