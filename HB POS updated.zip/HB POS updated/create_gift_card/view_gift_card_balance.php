<?php
include '../resources/config.php';

// Retrieve gift card balances from the database
$query = "SELECT CardNumber, Balance, Status FROM gift_cards";
$result = mysqli_query($conn, $query);

// Check if there are any gift cards
if (mysqli_num_rows($result) > 0) {
    // Gift cards found, display them in a table
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>View Gift Card Balances</title>
</head>
<body>
<!-- Menu -->
<div class="menu-container">
    <a href="../sales.html" class="menu-item">Sales</a>
    <a href="../view_inventory.html" class="menu-item">View Inventory</a>
    <a href="../add_product/add_product.html" class="menu-item">Add Product</a>
    <a href="../view_customers.html" class="menu-item">View Customers</a>
    <a href="../add_customer/add_customer.html" class="menu-item">Add Customer</a>
    <a href="process_return.html" class="menu-item">Process Return</a>
    <a href="create_gift_card.php" class="menu-item">Create Gift Card</a>
    <button onclick="window.location.href = '../logout.php'">Logout</button>
</div>

<h1>View Gift Card Balances</h1>
<table>
    <thead>
        <tr>
            <th>Card Number</th>
            <th>Balance</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo $row['CardNumber']; ?></td>
            <td><?php echo $row['Balance']; ?></td>
            <td><?php echo $row['Status']; ?></td>
        </tr>
        <?php } ?>
    </tbody>
</table>
</body>
</html>
<?php
} else {
    // No gift cards found
    echo "No gift cards available.";
}
?>
