<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>Edit Gift Card</title>
</head>
<body>
    <!-- Menu -->
    <div class="menu-container">
        <!-- Add your menu items here -->
    </div>

    <h1>Edit Gift Card</h1>

    <!-- Your form for editing gift card details -->

    <!-- Reload Gift Card button -->
    <form action="reload_card.php" method="GET">
        <input type="hidden" name="cardNumber" value="<?php echo $cardNumber; ?>">
        <button type="submit">Reload Gift Card</button>
    </form>
</body>
</html>
