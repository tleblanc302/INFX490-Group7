<?php
// Include your database configuration file
include '../resources/config.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establish a database connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check the connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Retrieve form data
    $cardNumber = mysqli_real_escape_string($conn, $_POST['cardNumber']);
    $balance = mysqli_real_escape_string($conn, $_POST['balance']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    // Insert gift card details into the database
    $query = "INSERT INTO gift_cards (CardNumber, Balance, Status) VALUES ('$cardNumber', '$balance', '$status')";

    // Execute the query
    if (mysqli_query($conn, $query)) {
        // Gift card created successfully, you can redirect to a success page
        header("Location: create_success.php");
        exit();
    } else {
        // Handle the error, redirect to an error page or show a message
        echo "Error creating gift card: " . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>Create Gift Card</title>
</head>
<body>
<!-- Menu -->
<div class="menu-container">
    <!-- Your menu items -->
</div>

<h1>Create Gift Card</h1>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
    <label for="cardNumber">Card Number:</label>
    <input type="text" id="cardNumber" name="cardNumber">

    <label for="balance">Balance:</label>
    <input type="text" id="balance" name="balance">

    <label for="status">Status:</label>
    <select id="status" name="status">
        <option value="active">Active</option>
        <option value="inactive">Inactive</option>
    </select>

    <button type="submit">Create Gift Card</button>
</form>
</body>
</html>
