<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="3;url=../sales/sales.html">
    <link rel="stylesheet" href="../style.css">
    <title>Edit Successful</title>
</head>
<body>
<h1>Created Successfully</h1>
<p>The Gift Card has been activated successfully.</p>
<p>Redirecting you back to the sales screen...</p>
</body>
</html>
