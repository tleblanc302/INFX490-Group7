<?php
include '../resources/config.php';

// Assuming you have a database connection established

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $cardNumber = $_POST['cardNumber'];
    $adjustedBalance = $_POST['adjustedBalance'];

    // Query to update the gift card balance in the database
    $query = "UPDATE gift_cards
              SET Balance = Balance - $adjustedBalance
              WHERE CardNumber = '$cardNumber'";

    // Execute the query
    if (mysqli_query($conn, $query)) {
        // Gift card balance updated successfully
        echo json_encode(array("success" => true));
    } else {
        // Handle the error
        echo json_encode(array("success" => false, "error" => mysqli_error($conn)));
    }
} else {
    // Redirect to an error page or handle appropriately
    echo json_encode(array("success" => false, "error" => "Invalid request method"));
}
?>
