<?php
// Include database configuration
include '../resources/config.php';

// Fetch gift card number from POST data
$giftCardNumber = $_POST['giftCardNumber'];

// Validate gift card number
if (empty($giftCardNumber)) {
    echo json_encode(['success' => false, 'message' => 'Gift card number is required.']);
    exit;
}

// Fetch gift card balance from the database
$stmt = $conn->prepare("SELECT Balance FROM gift_cards WHERE CardNumber = ?");
$stmt->bind_param("s", $giftCardNumber);

if (!$stmt->execute()) {
    echo json_encode(['success' => false, 'message' => 'Error executing query: ' . $stmt->error]);
    exit;
}

$stmt->bind_result($balance);
$stmt->fetch();
$stmt->close();

// Check if balance was fetched successfully
if (!empty($balance)) {
    echo json_encode(['success' => true, 'balance' => $balance]);
} else {
    echo json_encode(['success' => false, 'message' => 'Gift card not found or balance could not be retrieved.']);
}
?>
