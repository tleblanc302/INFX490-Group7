<?php
// Assuming you have a database connection already established

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the gift card number from the POST data
    $giftCardNumber = $_POST["giftCardNumber"];

    // Query the database to get the balance of the gift card
    $query = "SELECT Balance FROM gift_cards WHERE CardNumber = ?";
    $statement = $pdo->prepare($query);
    $statement->execute([$giftCardNumber]);
    $row = $statement->fetch(PDO::FETCH_ASSOC);

    // Check if a row was returned
    if ($row) {
        // Gift card balance found, return it as JSON response
        $balance = $row["Balance"];
        echo json_encode(["success" => true, "balance" => $balance]);
        exit;
    } else {
        // Gift card not found, return an error message
        echo json_encode(["success" => false, "message" => "Gift card not found"]);
        exit;
    }
} else {
    // If the request method is not POST, return an error message
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
    exit;
}
?>
