<?php
// Include your database configuration file
include '../resources/config.php';

// Check if the request is a POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve transaction ID from the request
    $transactionID = $_POST['transactionID'];

    // Log the received transaction ID
    file_put_contents('debug.log', 'Transaction ID: ' . $transactionID . PHP_EOL, FILE_APPEND);

    // Query to retrieve transaction details based on the provided transaction ID
    $query = "SELECT TransactionDate, TotalAmount FROM transactions WHERE TransactionID = '$transactionID'";

    // Execute the query
    $result = mysqli_query($conn, $query);

    if ($result) {
        // Check if transaction details are found
        if (mysqli_num_rows($result) > 0) {
            // Fetch transaction details
            $transactionData = mysqli_fetch_assoc($result);

            // Return transaction details as JSON response
            echo json_encode($transactionData);
        } else {
            // No transaction found for the provided ID
            echo json_encode(['error' => 'No transaction found for the provided ID.']);
        }
    } else {
        // Error executing the query
        echo json_encode(['error' => 'Error executing the query: ' . mysqli_error($conn)]);
    }
}
?>
