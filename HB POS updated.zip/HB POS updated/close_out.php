<?php
// Include the database connection file
require_once('resources/config.php');

// Check if the employee ID is provided
if (!isset($_GET['employee_id'])) {
    // Redirect back to the login page if employee ID is not provided
    header("Location: index.php");
    exit;
}

// Get the employee ID from the URL parameter
$employeeId = $_GET['employee_id'];

// Fetch the last shift data for the employee
$stmt = $conn->prepare("SELECT * FROM shift WHERE employee_id = ? ORDER BY shift_id DESC LIMIT 1");
$stmt->bind_param("s", $employeeId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Shift data found
    $shiftData = $result->fetch_assoc();
    // Display shift information
    echo "<h2>Shift Details</h2>";
    echo "<p>Employee ID: " . $shiftData['employee_id'] . "</p>";
    echo "<p>Shift Date: " . $shiftData['shift_date'] . "</p>";
    echo "<p>Shift Time: " . $shiftData['shift_time'] . " hours</p>";
    echo "<p>Total Transactions: " . $shiftData['total_transactions'] . "</p>";
    echo "<p>Total Cash: $" . $shiftData['total_cash'] . "</p>";
    echo "<p>Total Checks: $" . $shiftData['total_checks'] . "</p>";
    echo "<p>Total Card Sales: $" . $shiftData['total_card_sales'] . "</p>";
    echo "<p>Total Sales: $" . $shiftData['total_sales'] . "</p>";

    // Add print button
    echo "<button onclick=\"printAndOpenCashDrawer()\">Print Report</button>";
} else {
    // No shift data found for the employee
    echo "<h2>No Shift Data Found</h2>";
}

// Close the database connection
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shift Close-Out</title>
</head>
<body>
    <script src="../ePOS_SDK_Sample_JavaScript/epos-2.27.0.js"></script>
    <script>
        // Function to print receipt and open cash drawer
        function printAndOpenCashDrawer() {
            // Execute added code for printing
            executeAddedCode();
            // Open cash drawer
            openDrawer();
        }

        var canvas = document.getElementById('canvas');
        var printer = null;
        var ePosDev = new epson.ePOSDevice();
        ePosDev.connect('192.168.1.150', 8008, cbConnect);

        function cbConnect(data) {
            if(data == 'OK') {
                ePosDev.createDevice('local_printer', ePosDev.DEVICE_TYPE_PRINTER, {'crypto' : true, 'buffer' : false}, cbCreateDevice_printer);
            } else {
                console.log(data);
                // Handle connection error here
                // For example, you can display an error message to the user or retry connecting
            }
        }

        function cbCreateDevice_printer(devobj, retcode) {
            if (retcode == 'OK') {
                printer = devobj;
            } else {
                console.log(retcode);
                // Handle device creation error here
                // For example, you can display an error message to the user or retry creating the device
            }
        }

        // Function to execute added code for printing
        function executeAddedCode() {
            // Fetch shift data asynchronously
            fetchShiftData()
                .then(shiftData => {
                    // Construct receipt content using fetched shift data
                    const receiptContent = constructReceiptContent(shiftData);

                    // Print receipt content
                    if (printer) {
                        printer.addText(receiptContent);
                        printer.addFeedLine(3);
                        printer.addFeedPosition(printer.FEED_CUTTING);
                        printer.addCut(printer.FULL_CUT_NO_RESERVE);
                        printer.send();
                    } else {
                        console.error('Printer device not initialized.');
                    }
                })
                .catch(error => {
                    console.error('Error fetching shift data:', error);
                });
        }
        // Function to open cash drawer
        function openDrawer() {
            if (printer) {
                printer.addPulse(printer.DRAWER_1, printer.PULSE_100);
                printer.send();
            } else {
                console.error('Printer device not initialized.');
            }
        }
        // Function to construct receipt content for shift report
        function constructReceiptContent(shiftData) {
            // Initialize receipt content
            let receiptContent = '';

            // Add store information
            receiptContent += 'Honey-Be\'s\n1102 S. Union St.\nSuite 4\n337.4691466\n\n';

            // Add shift details
            receiptContent += 'Shift Report\n';
            receiptContent += `Employee ID: ${shiftData.employee_id}\n`;
            receiptContent += `Shift Date: ${shiftData.shift_date}\n`;
            receiptContent += `Shift Time: ${shiftData.shift_time} hours\n`;
            receiptContent += `Total Transactions: ${shiftData.total_transactions}\n`;
            receiptContent += `Total Cash: $${shiftData.total_cash}\n`;
            receiptContent += `Total Checks: $${shiftData.total_checks}\n`;
            receiptContent += `Total Card Sales: $${shiftData.total_card_sales}\n`;
            receiptContent += `Total Sales: $${shiftData.total_sales}\n\n`;

            // Add current date and time
            const currentDate = new Date();
            receiptContent += `Report generated on: ${currentDate.toLocaleString()}\n\n`;

            // Add footer
            receiptContent += 'Thank you!\n';

            return receiptContent;
        }
    </script>
</body>
</html>
