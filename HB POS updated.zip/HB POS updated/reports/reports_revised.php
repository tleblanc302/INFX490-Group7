<?php
// Include database configuration
include '../resources/config.php';

// Query to get total number of transactions
$query = "SELECT COUNT(*) AS totalTransactions FROM transactions";
$result = mysqli_query($conn, $query);
$totalTransactions = mysqli_fetch_assoc($result)['totalTransactions'];

// Query to get total amount of all transactions
$query = "SELECT SUM(TotalAmount) AS totalAmount FROM transactions";
$result = mysqli_query($conn, $query);
$totalAmount = mysqli_fetch_assoc($result)['totalAmount'];

// Calculate taxes collected (10.2% of total sales)
$taxesCollected = $totalAmount * 0.102;

// Query to get list of all items sold with their information
$query = "SELECT
              s.SaleID,
              s.CustomerID,
              s.SaleDate,
              t.TransactionID,
              i.ProductID,
              p.ProductName,
              p.SellingPrice,
              p.CostPrice
          FROM
              sales s
          INNER JOIN
              transactions t ON s.SaleID = t.SaleID
          INNER JOIN
              items_sold i ON s.SaleID = i.SaleID
          INNER JOIN
              products p ON i.ProductID = p.ProductID
          ORDER BY
              s.SaleDate, t.TransactionID";
$result = mysqli_query($conn, $query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Reports</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .sales-total {
            background-color: #ffd700; /* Highlight color for sales total line */
        }
    </style>
</head>
<body>
    <h1>Sales Reports</h1>

    <h2>Total Number of Transactions: <?php echo $totalTransactions; ?></h2>
    <h2>Total Amount of All Transactions: $<?php echo number_format($totalAmount, 2); ?></h2>
    <h2>Taxes Collected (10.2% of Total Sales): $<?php echo number_format($taxesCollected, 2); ?></h2>

    <h2>List of Items Sold:</h2>
    <table>
        <tr>
            <th>Transaction ID</th>
            <th>Sale ID</th>
            <th>Customer ID</th>
            <th>Sale Date</th>
            <th>Product ID</th>
            <th>Product Name</th>
            <th>Selling Price</th>
            <th>Cost Price</th>
        </tr>
        <?php
        $prevTransactionID = null;
        while ($row = mysqli_fetch_assoc($result)) {
            // Highlight sales total line
            $currentDate = $row['SaleDate'];
            $dateClass = ($prevDate !== null && $currentDate !== $prevDate) ? 'sales-total' : '';
            $prevDate = $currentDate;

            // If new Transaction ID, query TotalAmount from transactions table
            if ($row['TransactionID'] !== $prevTransactionID) {
                // Query TotalAmount for current Transaction ID
                $queryTotalAmount = "SELECT TotalAmount FROM transactions WHERE TransactionID = " . $row['TransactionID'];
                $resultTotalAmount = mysqli_query($conn, $queryTotalAmount);
                $rowTotalAmount = mysqli_fetch_assoc($resultTotalAmount);
                $transactionTotalPrice = $rowTotalAmount['TotalAmount'];

                // Display transaction totals for previous Transaction ID
                ?>
                <tr>
                    <td colspan="6">Transaction Totals with 10.2% taxes added:
                    $<?php echo number_format($transactionTotalPrice, 2); ?></td>

                <?php
            }

            // Display item details
            ?>
            <tr class="<?php echo $dateClass; ?>">
                <td><?php echo $row['TransactionID']; ?></td>
                <td><?php echo $row['SaleID']; ?></td>
                <td><?php echo $row['CustomerID']; ?></td>
                <td><?php echo $row['SaleDate']; ?></td>
                <td><?php echo $row['ProductID']; ?></td>
                <td><?php echo $row['ProductName']; ?></td>
                <td>$<?php echo number_format($row['SellingPrice'], 2); ?></td>
                <td>$<?php echo number_format($row['CostPrice'], 2); ?></td>
            </tr>

            <?php

            // Track previous Transaction ID
            $prevTransactionID = $row['TransactionID'];
        }
        ?>

        <!-- Display totals for the last Transaction ID -->


        <!-- Display totals for all sales -->

    </table>

    <?php
    // Close database connection
    mysqli_close($conn);
    ?>
</body>
</html>
