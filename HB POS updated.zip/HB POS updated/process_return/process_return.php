<?php
// Include your database configuration file
include '../resources/config.php';

// Initialize variables
$returnError = "";
$transactionData = [];

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $transactionID = $_POST['transactionID'];

    // Query to retrieve items sold in the specified transaction along with transaction date and total transaction price
    $query = "SELECT items_sold.ProductID, products.ProductName, items_sold.QuantitySold, items_sold.PricePerItem,
                     transactions.TransactionDate, transactions.TotalAmount
              FROM items_sold
              INNER JOIN sales ON items_sold.SaleID = sales.SaleID
              INNER JOIN transactions ON sales.SaleID = transactions.SaleID
              INNER JOIN products ON items_sold.ProductID = products.ProductID
              WHERE transactions.TransactionID = '$transactionID'";

    // Execute the query
    $result = mysqli_query($conn, $query);

    // Check if there are any returned items
    if (mysqli_num_rows($result) > 0) {
        // Fetch returned items and store them in an array
        while ($row = mysqli_fetch_assoc($result)) {
            $transactionData[] = $row;
        }
    } else {
        // No items found for the specified transaction
        $returnError = "No items found for the specified transaction.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <style>
        /* CSS for layout */
        .content-container {
            display: flex;
            justify-content: space-between;
        }

        .left-half {
           width: 25%; /* Adjust the width as needed */
        }
        .right-half,
        .far-right {
            width: calc(37.5% - 10px); /* Adjust the width as needed */
        }

        .left-half,
        .right-half {
            margin-right: 10px;
        }

        .left-half,
        .right-half,
        .far-right {
            border: 1px solid #ccc;
            padding: 10px;
            box-sizing: border-box;
        }
    </style>
    <title>Process Return</title>
</head>
<body>
<!-- Menu -->
<div class="menu-container">
    <a href="../sales/sales.html" class="menu-item">Sales</a>
    <a href="../view_inventory_sales.html" class="menu-item">View Inventory</a>
    <a href="../view_customers.html" class="menu-item">View Customers</a>
    <a href="../add_customer/add_customer.html" class="menu-item">Add Customer</a>
    <a href="process_return.php" class="menu-item">Process Return</a>
    <a href="../create_gift_card/gift_cards.php" class="menu-item">Gift Card</a>
    <button onclick="window.location.href = '../logout.php'">Logout</button>
</div>

<!-- Main Content Container -->
<div class="content-container">
    <!-- Left Half: Transaction ID Input Form -->
    <div class="left-half">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <label for="transactionID">Transaction ID:</label>
            <input type="text" id="transactionID" name="transactionID" required>
            <button type="submit">Submit</button>
        </form>
    </div>

    <!-- Right Half: Transaction Details -->
    <div class="right-half">
        <?php if (!empty($transactionData)) { ?>
            <h2>Transaction Details</h2>
            <p><strong>Date Sold:</strong> <?php echo $transactionData[0]['TransactionDate']; ?></p>
            <p><strong>Total Transaction Price:</strong> <?php echo $transactionData[0]['TotalAmount']; ?></p>

            <h2>Items Sold in Transaction</h2>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                <table>
                    <thead>
                        <tr>
                            <th>Product ID</th>
                            <th>Product Name</th>
                            <th>Price Per Item</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($transactionData as $item) { ?>
                            <tr data-product-id="<?php echo $item['ProductID']; ?>" data-price="<?php echo $item['PricePerItem']; ?>">
                                <td><?php echo $item['ProductID']; ?></td>
                                <td><?php echo $item['ProductName']; ?></td>
                                <td><?php echo $item['PricePerItem']; ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </form>
        <?php } ?>
    </div>

    <!-- Far Right: Selected Items and Running Total -->
    <div class="far-right">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" id="returnForm">
            <h2>Selected Items for Return</h2>
            <ul id="selectedItemsList"></ul>
            <p><strong>Total Price with Tax:</strong> <span id="totalPrice">$0.00</span></p>
            <label for="giftCardNumber">Enter Gift Card Number:</label>
            <input type="text" id="giftCardNumber" name="giftCardNumber" required>
            <button type="button" id="addToGiftCard">Add to Gift Card</button>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const tableRows = document.querySelectorAll('.right-half table tbody tr');
        const selectedItemsList = document.getElementById('selectedItemsList');
        const totalPriceElement = document.getElementById('totalPrice');
        let selectedItems = [];

        tableRows.forEach(function (row) {
            row.addEventListener('click', function () {
                const productId = row.getAttribute('data-product-id');
                const price = parseFloat(row.getAttribute('data-price'));

                if (selectedItems.includes(productId)) {
                    selectedItems = selectedItems.filter(item => item !== productId);
                } else {
                    selectedItems.push(productId);
                }

                updateSelectedItemsList();
                updateTotalPrice();
            });
        });

        function updateSelectedItemsList() {
            selectedItemsList.innerHTML = '';
            selectedItems.forEach(function (productId) {
                const productName = document.querySelector(`.right-half table tbody tr[data-product-id="${productId}"] td:nth-child(2)`).innerText;
                const listItem = document.createElement('li');
                listItem.textContent = `${productName} - $${parseFloat(document.querySelector(`.right-half table tbody tr[data-product-id="${productId}"]`).getAttribute('data-price')).toFixed(2)}`;
                selectedItemsList.appendChild(listItem);
            });
        }

        function updateTotalPrice() {
            let totalPrice = 0;
            selectedItems.forEach(function (productId) {
                totalPrice += parseFloat(document.querySelector(`.right-half table tbody tr[data-product-id="${productId}"]`).getAttribute('data-price'));
            });
            const totalPriceWithTax = totalPrice * 1.1; // Assuming 10% tax
            totalPriceElement.textContent = '$' + totalPriceWithTax.toFixed(2);
        }

        document.getElementById('addToGiftCard').addEventListener('click', function () {
            const giftCardNumber = document.getElementById('giftCardNumber').value;
            const totalPrice = parseFloat(totalPriceElement.textContent.replace('$', ''));

            // Perform AJAX request to add gift card data to database
            const xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        alert(xhr.responseText); // Show success message
                    } else {
                        alert('Error: Failed to add money to gift card.'); // Show error message
                    }
                }
            };
            xhr.open('POST', 'add_to_gift_card.php');
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.send(`cardNumber=${giftCardNumber}&balance=${totalPrice}`);
        });
    });
</script>

</body>
</html>
