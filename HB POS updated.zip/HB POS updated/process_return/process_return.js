// Function to fetch transaction details based on transaction ID
// Function to fetch transaction details based on transaction ID
function fetchTransactionDetails() {
    let transactionID = document.getElementById("TransactionID").value;

    // Make a fetch request to the server to retrieve transaction details
    fetch('../fetch_transactions.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ transactionID: transactionID }),
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Response from server:', data); // Log the response
            // Update UI with fetched transaction details
            document.getElementById("TransactionDate").innerText = "Date: " + data.TransactionDate;
            document.getElementById("TotalAmount").innerText = "Total Amount: $" + data.TotalAmount.toFixed(2);
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while fetching transaction details. Please try again.');
        });
}


// Function to process return
function processReturn() {
    // Here you would implement the logic to process the return, such as updating the database, generating a receipt, etc.
    // For demonstration purposes, I'll just log a message
    console.log("Return processed successfully!");
}
