<?php
// Include your database configuration file
include '../resources/config.php';

// Retrieve POST data
$cardNumber = $_POST['cardNumber'];
$balance = $_POST['balance'];

// Prepare SQL statement
$query = "INSERT INTO gift_cards (CardNumber, Balance, Status) VALUES ('$cardNumber', $balance, 'active')";

// Execute SQL statement
if (mysqli_query($conn, $query)) {
    echo "Money added to gift card successfully.";
} else {
    echo "Error: " . mysqli_error($conn);
}

// Close database connection
mysqli_close($conn);
?>
