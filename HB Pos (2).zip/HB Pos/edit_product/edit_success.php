<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="3;url=../view_inventory.html">
    <link rel="stylesheet" href="../style.css">
    <title>Edit Successful</title>
</head>
<body>
<h1>Edit Successful</h1>
<p>The product details have been updated successfully.</p>
<p>Redirecting you back to the inventory...</p>
</body>
</html>
